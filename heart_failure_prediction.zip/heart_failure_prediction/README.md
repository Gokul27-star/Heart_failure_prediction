# Heart Failure Prediction App

This Streamlit app predicts the risk of heart failure based on clinical records using a trained Random Forest model.

## How to Run

1. Install requirements:

```
pip install -r requirements.txt
```

2. Train the model:

```
python train_model.py
```

3. Run the app:

```
streamlit run app.py
```