import streamlit as st
import pandas as pd
from utils.predict import predict_heart_failure

st.title("Heart Failure Prediction App")

st.sidebar.header("Patient Data Input")

age = st.sidebar.slider("Age", 20, 100, 50)
anaemia = st.sidebar.selectbox("Anaemia", [0, 1])
creatinine_phosphokinase = st.sidebar.number_input("Creatinine Phosphokinase", 0, 10000, 250)
diabetes = st.sidebar.selectbox("Diabetes", [0, 1])
ejection_fraction = st.sidebar.slider("Ejection Fraction", 10, 80, 40)
high_blood_pressure = st.sidebar.selectbox("High Blood Pressure", [0, 1])
platelets = st.sidebar.number_input("Platelets", 0.0, 1000000.0, 250000.0)
serum_creatinine = st.sidebar.number_input("Serum Creatinine", 0.0, 10.0, 1.0)
serum_sodium = st.sidebar.number_input("Serum Sodium", 100, 150, 137)
sex = st.sidebar.selectbox("Sex (Male=1, Female=0)", [0, 1])
smoking = st.sidebar.selectbox("Smoking", [0, 1])
time = st.sidebar.slider("Follow-up Period (days)", 0, 300, 100)

input_data = {
    "age": age,
    "anaemia": anaemia,
    "creatinine_phosphokinase": creatinine_phosphokinase,
    "diabetes": diabetes,
    "ejection_fraction": ejection_fraction,
    "high_blood_pressure": high_blood_pressure,
    "platelets": platelets,
    "serum_creatinine": serum_creatinine,
    "serum_sodium": serum_sodium,
    "sex": sex,
    "smoking": smoking,
    "time": time
}

if st.button("Predict"):
    result = predict_heart_failure(input_data)
    st.subheader("Prediction Result")
    st.success(f"The patient is at **{'HIGH' if result == 1 else 'LOW'}** risk of heart failure.")