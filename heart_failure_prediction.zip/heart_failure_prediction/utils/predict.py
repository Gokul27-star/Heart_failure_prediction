import joblib
import pandas as pd

def predict_heart_failure(input_data):
    model = joblib.load("model/model.pkl")
    df = pd.DataFrame([input_data])
    prediction = model.predict(df)[0]
    return prediction