# Heart Failure Prediction App

This project predicts heart failure using a machine learning model.